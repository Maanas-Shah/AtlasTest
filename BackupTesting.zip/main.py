
#Introduction Code
wanttoplay = input("""Would you like to play a little game?\n""")
if (wanttoplay == "no"):
 print ("So sad to see you go. Come back another time!")
 exit()
else:
  if (wanttoplay == "yes"):
    print ("Great!")
    howtoplay = input("""Do you know how to play Atlas?\n""")
    #Gameplay Code if they don't know how to play
    if (howtoplay == "no"):
      print ("Well this is how you play: \nFirst, we start with any country. Let's say America. Since America ends with the letter A, you have to say a country starting with A. Then I will say a country starting with the last letter of the place you said. I know, it is a little confusing. Let's try it! I'll start!") 
      print("")
      from random import choice
      countries = open("countrieslist.txt", "r")
      countries_list = countries.read().split("\n")
      final_choice = choice(countries_list)
      country_imput = input(final_choice)
      
    #Gameplay Code if they do know how to play
    if(howtoplay == "yes"):
      print ("Excellent! Today we will be playing the game using only countries. Let's begin! I'll start!") 
      print("")
      from random import choice
      countries = open("countrieslist.txt", "r")
      countries_list = countries.read().split("\n")
      final_choice = choice(countries_list)
      country_imput = input(final_choice)
      
    else:
      print ("I'm sorry I cannot understand you. Can you please restart and type in yes or no next time?")
      quit()
  else:
    print ("I'm sorry I cannot understand you. Can you please restart and type in yes or no next time?")
    quit()